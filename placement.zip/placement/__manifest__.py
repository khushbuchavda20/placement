{
    'name':'Placement Management',
    'category' : 'Sales',
    'application' : True,
    'data' : [
        # 'security/ir.model.access.csv',
        'views/placement_menus.xml',
        'views/placement_views.xml',
        'views/placement_website.xml',
        # 'security/security.xml',
    ]
}